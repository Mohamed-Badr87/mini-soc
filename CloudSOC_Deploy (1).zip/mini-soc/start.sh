#!/usr/bin/env bash
# One start command for any host (VM, PaaS, Docker):  bash start.sh
set -e
cd "$(dirname "$0")"

# Behind a platform proxy/load balancer the real client IP comes from X-Forwarded-For.
# 1 = one proxy in front (most platforms). Use 0 only if users reach gunicorn directly.
export PROXY_HOPS="${PROXY_HOPS:-1}"

# Railway serves every app over https, so mark the session cookie as Secure there.
if [ -n "$RAILWAY_ENVIRONMENT" ] || [ -n "$RAILWAY_PUBLIC_DOMAIN" ]; then
  export SESSION_COOKIE_SECURE="${SESSION_COOKIE_SECURE:-true}"
fi

if [ -z "$SECRET_KEY" ]; then
  echo "WARNING: SECRET_KEY is not set. Using a random one: admin sessions reset on every restart."
  export SECRET_KEY="$(python -c 'import secrets; print(secrets.token_hex(32))')"
fi

flask --app wsgi init-db

if [ -n "$ADMIN_PASSWORD" ]; then
  flask --app wsgi create-admin --username "${ADMIN_USERNAME:-admin}" || true
else
  echo "NOTE: ADMIN_PASSWORD is not set, so no admin account is created (set it once, then you can remove it)."
fi

exec gunicorn --workers 1 --threads 8 --worker-class gthread \
  --bind "0.0.0.0:${PORT:-8000}" --timeout 30 --access-logfile - wsgi:app
