# خطوات الرفع (أي منصة)

## 1) ارفع الكود
ارفع **اللي جوه فولدر `mini-soc`** (اللي فيه `Procfile` و`start.sh` و`wsgi.py`) على GitHub كـ repo جديد. الملفات دي لازم تكون في أول الـ repo مش جوه فولدر تاني.

## 2) إعدادات المنصة
| الخانة | القيمة |
|---|---|
| Build command | `pip install -r requirements.txt` |
| Start command | `bash start.sh` |
| Port | المنصة بتبعته في المتغير `PORT` (الـ script بيستخدمه لوحده) |
| Python | 3.11 أو 3.12 |

لو المنصة بتشغل Docker: فيه `Dockerfile` جاهز (بيشغل `start.sh` على بورت 8000).

## 3) Environment variables
| الاسم | القيمة | ملاحظة |
|---|---|---|
| `SECRET_KEY` | نص عشوائي طويل | **لازم**. بدونه الأدمن بيتسجل خروج مع كل restart |
| `ADMIN_PASSWORD` | باسورد 10 حروف أو أكتر | بيعمل حساب الأدمن (`admin`) أول مرة بس |
| `PROXY_HOPS` | `1` (الافتراضي) | **مهم**: من غيره كل الزوار بيبانوا بـ IP واحد. اكتب `0` فقط لو الناس بتدخل على gunicorn مباشرة من غير proxy |
| `SESSION_COOKIE_SECURE` | `true` | لو الموقع على https |
| `DATABASE_URL` | رابط الداتابيز | اختياري (تحت) |

## 4) الداتابيز
- من غير `DATABASE_URL` بيستخدم SQLite، وده بيتمسح لو المنصة بتعمل redeploy أو restart على ملفات مؤقتة.
- لو المنصة بتدّيك **MySQL**: حط رابطها في `DATABASE_URL` (شغالة مباشرة).
- لو بتدّيك **PostgreSQL**: خلي الـ Build command `pip install -r requirements.txt psycopg2-binary` (الـ Dockerfile بيعملها لوحده).

## 5) بعد ما يشتغل
- المستخدم: `https://<الرابط>/login`
- الأدمن: `https://<الرابط>/admin/login` (admin + `ADMIN_PASSWORD`)
- فحص الصحة: `https://<الرابط>/health` لازم يرد `ok`
- اللوج بيطلع في صفحة Logs بتاعة المنصة (JSON)، مش في ملف.

## لو حصلت مشكلة
- **كل الناس اتحظرت مرة واحدة** ← `PROXY_HOPS` غلط (جرّب 1 أو 2).
- **الأدمن مبيدخلش** ← `ADMIN_PASSWORD` مكانش متضبط أول مرة. حطه وأعد التشغيل (لو الأدمن موجود بالفعل مش هيتغير باسورده، امسح الداتابيز أو استخدم أمر reset).
- **500 Error** ← افتح Logs المنصة وابعتلي آخر 10 سطور.
